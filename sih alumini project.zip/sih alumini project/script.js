document.addEventListener('DOMContentLoaded', function() {
    const chatbox = document.getElementById('chatbox');
    const userInput = document.getElementById('userInput');
    const sendMessage = document.getElementById('sendMessage');

    // Sample dataset with predefined alumni profiles
    const alumniProfiles = {
        'machine learning': [
            { name: 'Dr. Anil Kumar', position: 'Data Scientist', company: 'TechCorp', expertise: 'AI and ML algorithms' },
            { name: 'Ms. Priya Sharma', position: 'ML Engineer', company: 'InnovateAI', expertise: 'Neural networks and deep learning' },
            { name: 'Mr. Raj Patel', position: 'Senior Data Analyst', company: 'DataInsights', expertise: 'Predictive analytics and ML models' }
        ],
        'software development': [
            { name: 'Ms. Ananya Rao', position: 'Software Developer', company: 'CodeWorks', expertise: 'Full stack development' },
            { name: 'Mr. Vikram Singh', position: 'Senior Software Engineer', company: 'SoftSolutions', expertise: 'Backend systems and APIs' }
        ]
    };

    function addMessage(text, sender) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}`;
        messageDiv.innerText = text;
        chatbox.appendChild(messageDiv);
        chatbox.scrollTop = chatbox.scrollHeight;
    }

    function handleUserInput() {
        const query = userInput.value.trim().toLowerCase();
        if (query === '') return;

        addMessage(query, 'user');
        userInput.value = '';

        // Generate bot response based on user query
        setTimeout(() => {
            const response = generateBotResponse(query);
            addMessage(response, 'bot');
        }, 1000);
    }

    function generateBotResponse(query) {
        let response = 'Sorry, I didn\'t understand that. Can you please be more specific?';

        // Check if query matches any known expertise
        for (const [key, profiles] of Object.entries(alumniProfiles)) {
            if (query.includes(key)) {
                response = `Here are some alumni with expertise in ${key}:
                ${profiles.map(p => `1. **${p.name}** - ${p.position} at ${p.company} - Specializes in ${p.expertise}`).join('\n')}
                
                Click on a name to view more details.`;
                break;
            }
        }

        return response;
    }

    // Attach event listeners
    sendMessage.addEventListener('click', handleUserInput);
    userInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            handleUserInput();
        }
    });
});
